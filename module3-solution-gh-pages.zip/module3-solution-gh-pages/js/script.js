$('nav').affix({
      offset: {
        top: $('header').height()
      }
});	


 